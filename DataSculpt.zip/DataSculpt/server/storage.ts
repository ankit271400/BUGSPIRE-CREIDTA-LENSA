import { 
  issuers, features, scores, events, eventImpacts, alerts, users,
  type Issuer, type InsertIssuer,
  type Feature, type InsertFeature,
  type Score, type InsertScore,
  type Event, type InsertEvent,
  type EventImpact, type InsertEventImpact,
  type Alert, type InsertAlert,
  type User, type InsertUser
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, gte, lte, count } from "drizzle-orm";

export interface IStorage {
  // User methods (legacy)
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Issuer methods
  getIssuers(): Promise<Issuer[]>;
  getIssuerBySymbol(symbol: string): Promise<Issuer | undefined>;
  createIssuer(issuer: InsertIssuer): Promise<Issuer>;

  // Feature methods
  getLatestFeatures(issuerId: string): Promise<Feature | undefined>;
  createFeature(feature: InsertFeature): Promise<Feature>;

  // Score methods
  getLatestScore(issuerId: string): Promise<Score | undefined>;
  getScoreHistory(issuerId: string, limit?: number): Promise<Score[]>;
  createScore(score: InsertScore): Promise<Score>;

  // Event methods
  getRecentEvents(issuerId: string, limit?: number): Promise<Event[]>;
  createEvent(event: InsertEvent): Promise<Event>;

  // Event Impact methods
  getEventImpacts(issuerId: string, limit?: number): Promise<EventImpact[]>;
  createEventImpact(impact: InsertEventImpact): Promise<EventImpact>;

  // Alert methods
  getActiveAlerts(limit?: number): Promise<Alert[]>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  markAlertAsRead(alertId: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User methods (legacy)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Issuer methods
  async getIssuers(): Promise<Issuer[]> {
    return await db.select().from(issuers).orderBy(issuers.name);
  }

  async getIssuerBySymbol(symbol: string): Promise<Issuer | undefined> {
    const [issuer] = await db.select().from(issuers).where(eq(issuers.symbol, symbol));
    return issuer || undefined;
  }

  async createIssuer(insertIssuer: InsertIssuer): Promise<Issuer> {
    const [issuer] = await db
      .insert(issuers)
      .values(insertIssuer)
      .returning();
    return issuer;
  }

  // Feature methods
  async getLatestFeatures(issuerId: string): Promise<Feature | undefined> {
    const [feature] = await db
      .select()
      .from(features)
      .where(eq(features.issuerId, issuerId))
      .orderBy(desc(features.timestamp))
      .limit(1);
    return feature || undefined;
  }

  async createFeature(insertFeature: InsertFeature): Promise<Feature> {
    const [feature] = await db
      .insert(features)
      .values(insertFeature)
      .returning();
    return feature;
  }

  // Score methods
  async getLatestScore(issuerId: string): Promise<Score | undefined> {
    const [score] = await db
      .select()
      .from(scores)
      .where(eq(scores.issuerId, issuerId))
      .orderBy(desc(scores.timestamp))
      .limit(1);
    return score || undefined;
  }

  async getScoreHistory(issuerId: string, limit: number = 30): Promise<Score[]> {
    return await db
      .select()
      .from(scores)
      .where(eq(scores.issuerId, issuerId))
      .orderBy(desc(scores.timestamp))
      .limit(limit);
  }

  async createScore(insertScore: InsertScore): Promise<Score> {
    const [score] = await db
      .insert(scores)
      .values(insertScore)
      .returning();
    return score;
  }

  // Event methods
  async getRecentEvents(issuerId: string, limit: number = 10): Promise<Event[]> {
    return await db
      .select()
      .from(events)
      .where(eq(events.issuerId, issuerId))
      .orderBy(desc(events.publishedAt))
      .limit(limit);
  }

  async createEvent(insertEvent: InsertEvent): Promise<Event> {
    const [event] = await db
      .insert(events)
      .values(insertEvent)
      .returning();
    return event;
  }

  // Event Impact methods
  async getEventImpacts(issuerId: string, limit: number = 10): Promise<EventImpact[]> {
    return await db
      .select()
      .from(eventImpacts)
      .where(eq(eventImpacts.issuerId, issuerId))
      .orderBy(desc(eventImpacts.timestamp))
      .limit(limit);
  }

  async createEventImpact(insertEventImpact: InsertEventImpact): Promise<EventImpact> {
    const [impact] = await db
      .insert(eventImpacts)
      .values(insertEventImpact)
      .returning();
    return impact;
  }

  // Alert methods
  async getActiveAlerts(limit: number = 50): Promise<Alert[]> {
    return await db
      .select()
      .from(alerts)
      .orderBy(desc(alerts.createdAt))
      .limit(limit);
  }

  async createAlert(insertAlert: InsertAlert): Promise<Alert> {
    const [alert] = await db
      .insert(alerts)
      .values(insertAlert)
      .returning();
    return alert;
  }

  async markAlertAsRead(alertId: string): Promise<void> {
    await db
      .update(alerts)
      .set({ isRead: true })
      .where(eq(alerts.id, alertId));
  }
}

export const storage = new DatabaseStorage();
