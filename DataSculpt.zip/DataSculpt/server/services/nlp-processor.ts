import { storage } from "../storage";
import { type Issuer, type InsertEvent, type InsertEventImpact } from "@shared/schema";

interface NewsArticle {
  title: string;
  content: string;
  source: string;
  publishedAt: Date;
  url: string;
}

interface SentimentAnalysisResult {
  sentiment: 'positive' | 'negative' | 'neutral';
  confidence: number;
  eventType?: string;
}

class NLPProcessor {
  private readonly NEWS_API_KEY = process.env.NEWS_API_KEY || process.env.VITE_NEWS_API_KEY || "demo_key";

  async processNewsForIssuer(issuer: Issuer): Promise<InsertEvent[]> {
    try {
      console.log(`Processing news for ${issuer.symbol}`);

      // Fetch recent news articles
      const articles = await this.fetchNewsArticles(issuer);
      const processedEvents: InsertEvent[] = [];

      for (const article of articles) {
        try {
          // Analyze sentiment and classify event type
          const analysis = await this.analyzeSentiment(article);
          
          // Create event record
          const event: InsertEvent = {
            issuerId: issuer.id,
            title: article.title,
            content: article.content,
            source: article.source,
            eventType: analysis.eventType || 'general_news',
            sentiment: analysis.sentiment,
            confidence: analysis.confidence.toString(),
            publishedAt: article.publishedAt,
          };

          const savedEvent = await storage.createEvent(event);
          processedEvents.push(event);

          // Calculate event impact if significant
          if (analysis.confidence > 0.7) {
            await this.calculateEventImpact(savedEvent, issuer);
          }

        } catch (error) {
          console.error(`Error processing article "${article.title}":`, error);
        }
      }

      console.log(`Processed ${processedEvents.length} news articles for ${issuer.symbol}`);
      return processedEvents;
    } catch (error) {
      console.error(`Error processing news for ${issuer.symbol}:`, error);
      throw error;
    }
  }

  private async fetchNewsArticles(issuer: Issuer): Promise<NewsArticle[]> {
    try {
      // Using News API to fetch recent articles
      const query = `${issuer.name} OR ${issuer.symbol}`;
      const response = await fetch(
        `https://newsapi.org/v2/everything?q=${encodeURIComponent(query)}&sortBy=publishedAt&pageSize=10&apiKey=${this.NEWS_API_KEY}`
      );

      if (!response.ok) {
        throw new Error(`News API error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.status !== 'ok') {
        console.warn(`News API warning: ${data.message}`);
        return [];
      }

      return data.articles.map((article: any) => ({
        title: article.title,
        content: article.description || article.content || '',
        source: article.source.name,
        publishedAt: new Date(article.publishedAt),
        url: article.url,
      }));
    } catch (error) {
      console.error(`Error fetching news for ${issuer.symbol}:`, error);
      return [];
    }
  }

  private async analyzeSentiment(article: NewsArticle): Promise<SentimentAnalysisResult> {
    try {
      // Simple keyword-based sentiment analysis
      // In production, this would use a proper NLP model
      const text = `${article.title} ${article.content}`.toLowerCase();
      
      // Define keyword patterns for sentiment and event classification
      const negativeKeywords = [
        'lawsuit', 'litigation', 'debt', 'bankruptcy', 'restructuring',
        'downgrade', 'loss', 'decline', 'crisis', 'investigation',
        'fraud', 'scandal', 'layoffs', 'cuts', 'warning'
      ];

      const positiveKeywords = [
        'upgrade', 'growth', 'profit', 'revenue', 'partnership',
        'acquisition', 'expansion', 'innovation', 'breakthrough',
        'success', 'record', 'strong', 'beat', 'outperform'
      ];

      const eventTypeKeywords = {
        'debt_restructuring': ['debt', 'restructuring', 'refinance', 'bond'],
        'litigation': ['lawsuit', 'litigation', 'court', 'legal'],
        'downgrade': ['downgrade', 'rating', 'outlook'],
        'guidance_cut': ['guidance', 'forecast', 'outlook', 'estimate'],
        'earnings': ['earnings', 'results', 'quarterly', 'revenue'],
        'partnership': ['partnership', 'deal', 'agreement', 'contract'],
        'acquisition': ['acquisition', 'merger', 'buyout', 'purchase'],
      };

      // Count keyword matches
      let negativeScore = 0;
      let positiveScore = 0;

      negativeKeywords.forEach(keyword => {
        if (text.includes(keyword)) negativeScore++;
      });

      positiveKeywords.forEach(keyword => {
        if (text.includes(keyword)) positiveScore++;
      });

      // Determine sentiment
      let sentiment: 'positive' | 'negative' | 'neutral';
      let confidence: number;

      if (negativeScore > positiveScore) {
        sentiment = 'negative';
        confidence = Math.min(0.9, 0.6 + (negativeScore - positiveScore) * 0.1);
      } else if (positiveScore > negativeScore) {
        sentiment = 'positive';
        confidence = Math.min(0.9, 0.6 + (positiveScore - negativeScore) * 0.1);
      } else {
        sentiment = 'neutral';
        confidence = 0.5;
      }

      // Determine event type
      let eventType: string | undefined;
      let maxMatches = 0;

      for (const [type, keywords] of Object.entries(eventTypeKeywords)) {
        const matches = keywords.filter(keyword => text.includes(keyword)).length;
        if (matches > maxMatches) {
          maxMatches = matches;
          eventType = type;
        }
      }

      return {
        sentiment,
        confidence,
        eventType,
      };
    } catch (error) {
      console.error("Error analyzing sentiment:", error);
      return {
        sentiment: 'neutral',
        confidence: 0.5,
      };
    }
  }

  private async calculateEventImpact(event: any, issuer: Issuer): Promise<void> {
    try {
      // Get scores before and after the event
      const scores = await storage.getScoreHistory(issuer.id, 10);
      
      if (scores.length < 2) {
        return; // Not enough score history
      }

      // Find the closest scores before and after the event
      const eventTime = new Date(event.publishedAt);
      let scorePre: number | null = null;
      let scorePost: number | null = null;

      for (const score of scores) {
        const scoreTime = new Date(score.timestamp!);
        
        if (scoreTime <= eventTime && scorePre === null) {
          scorePre = score.score;
        }
        
        if (scoreTime > eventTime && scorePost === null) {
          scorePost = score.score;
          break;
        }
      }

      // If we don't have both pre and post scores, use approximation
      if (scorePre === null || scorePost === null) {
        // Estimate impact based on sentiment and event type
        const baseImpact = this.estimateEventImpact(event);
        scorePre = scorePre || scores[0].score;
        scorePost = scorePost || (scorePre + baseImpact);
      }

      const scoreDelta = scorePost - scorePre;
      
      // Only create impact record if change is significant
      if (Math.abs(scoreDelta) >= 5) {
        const impactMagnitude = Math.abs(scoreDelta) >= 20 ? 'high' : 
                               Math.abs(scoreDelta) >= 10 ? 'medium' : 'low';

        const topDrivers = this.identifyTopDrivers(event, scoreDelta);

        const eventImpact: InsertEventImpact = {
          eventId: event.id,
          issuerId: issuer.id,
          scorePre,
          scorePost,
          scoreDelta,
          impactMagnitude,
          topDrivers,
        };

        await storage.createEventImpact(eventImpact);
      }
    } catch (error) {
      console.error("Error calculating event impact:", error);
    }
  }

  private estimateEventImpact(event: any): number {
    // Estimate impact based on event type and sentiment
    const baseImpacts: Record<string, number> = {
      'debt_restructuring': -15,
      'litigation': -10,
      'downgrade': -20,
      'guidance_cut': -8,
      'earnings': 5,
      'partnership': 8,
      'acquisition': 12,
    };

    const baseImpact = baseImpacts[event.eventType] || 0;
    
    // Adjust based on sentiment
    const sentimentMultiplier = {
      'positive': 1.0,
      'negative': 1.0,
      'neutral': 0.5,
    };

    // If sentiment conflicts with expected impact, reduce magnitude
    if ((baseImpact > 0 && event.sentiment === 'negative') ||
        (baseImpact < 0 && event.sentiment === 'positive')) {
      return baseImpact * -0.5;
    }

    return baseImpact * (sentimentMultiplier[event.sentiment as keyof typeof sentimentMultiplier] || 0.5) * event.confidence;
  }

  private identifyTopDrivers(event: any, scoreDelta: number): Record<string, any> {
    // Identify which features likely drove the score change
    const drivers: Record<string, any> = {};

    switch (event.eventType) {
      case 'debt_restructuring':
        drivers.leverageRatio = { change: scoreDelta * 0.4, reason: 'Debt restructuring impact' };
        drivers.cashCoverage = { change: scoreDelta * 0.3, reason: 'Cash flow concerns' };
        break;
      
      case 'earnings':
        drivers.revenueGrowth = { change: scoreDelta * 0.5, reason: 'Earnings performance' };
        drivers.stockPriceChange7d = { change: scoreDelta * 0.3, reason: 'Market reaction' };
        break;
      
      case 'partnership':
        drivers.revenueGrowth = { change: scoreDelta * 0.4, reason: 'Partnership synergies' };
        drivers.stockPriceChange7d = { change: scoreDelta * 0.3, reason: 'Positive market sentiment' };
        break;
      
      default:
        drivers.general = { change: scoreDelta, reason: 'General market sentiment' };
    }

    return drivers;
  }
}

export const nlpProcessor = new NLPProcessor();