import { storage } from "../storage";
import { type Issuer, type InsertFeature } from "@shared/schema";

interface YahooFinanceData {
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  marketCap: number;
  pegRatio?: number;
  debtToEquity?: number;
  returnOnEquity?: number;
}

interface AlphaVantageData {
  symbol: string;
  overview: {
    marketCap: string;
    ebitda: string;
    pegRatio: string;
    bookValue: string;
    debtToEquity: string;
    returnOnEquity: string;
    revenueGrowth: string;
  };
  earnings: {
    quarterlyEarnings: Array<{
      fiscalDateEnding: string;
      reportedEPS: string;
    }>;
  };
}

class DataIngestionService {
  private readonly YAHOO_FINANCE_API = process.env.YAHOO_FINANCE_API_KEY || process.env.VITE_YAHOO_FINANCE_API_KEY || "demo_key";
  private readonly ALPHA_VANTAGE_API = process.env.ALPHA_VANTAGE_API_KEY || process.env.VITE_ALPHA_VANTAGE_API_KEY || "demo_key";

  async ingestDataForIssuer(issuer: Issuer): Promise<void> {
    try {
      console.log(`Starting data ingestion for ${issuer.symbol}`);

      // Fetch data from multiple sources
      const [yahooData, alphaVantageData] = await Promise.allSettled([
        this.fetchYahooFinanceData(issuer.symbol),
        this.fetchAlphaVantageData(issuer.symbol),
      ]);

      // Process and combine data
      const features = this.combineAndProcessData(
        issuer,
        yahooData.status === 'fulfilled' ? yahooData.value : null,
        alphaVantageData.status === 'fulfilled' ? alphaVantageData.value : null
      );

      if (features) {
        await storage.createFeature(features);
        console.log(`Successfully ingested data for ${issuer.symbol}`);
      } else {
        console.warn(`No data could be processed for ${issuer.symbol}`);
      }
    } catch (error) {
      console.error(`Error ingesting data for ${issuer.symbol}:`, error);
      throw error;
    }
  }

  private async fetchYahooFinanceData(symbol: string): Promise<YahooFinanceData | null> {
    try {
      // Using a real Yahoo Finance API endpoint
      const response = await fetch(
        `https://query1.finance.yahoo.com/v8/finance/chart/${symbol}`,
        {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
          }
        }
      );

      if (!response.ok) {
        throw new Error(`Yahoo Finance API error: ${response.status}`);
      }

      const data = await response.json();
      const result = data.chart?.result?.[0];
      
      if (!result) {
        return null;
      }

      const meta = result.meta;
      const currentPrice = meta.regularMarketPrice || meta.previousClose;
      
      return {
        symbol,
        price: currentPrice,
        change: meta.regularMarketPrice - meta.previousClose,
        changePercent: ((meta.regularMarketPrice - meta.previousClose) / meta.previousClose) * 100,
        volume: meta.regularMarketVolume || 0,
        marketCap: meta.marketCap || 0,
      };
    } catch (error) {
      console.error(`Error fetching Yahoo Finance data for ${symbol}:`, error);
      return null;
    }
  }

  private async fetchAlphaVantageData(symbol: string): Promise<AlphaVantageData | null> {
    try {
      // Fetch company overview
      const overviewResponse = await fetch(
        `https://www.alphavantage.co/query?function=OVERVIEW&symbol=${symbol}&apikey=${this.ALPHA_VANTAGE_API}`
      );

      if (!overviewResponse.ok) {
        throw new Error(`Alpha Vantage API error: ${overviewResponse.status}`);
      }

      const overview = await overviewResponse.json();
      
      if (overview.Note || overview.Information) {
        console.warn(`Alpha Vantage API limit reached for ${symbol}`);
        return null;
      }

      return {
        symbol,
        overview: {
          marketCap: overview.MarketCapitalization || "0",
          ebitda: overview.EBITDA || "0",
          pegRatio: overview.PEGRatio || "0",
          bookValue: overview.BookValue || "0",
          debtToEquity: overview.DebtToEquityRatio || "0",
          returnOnEquity: overview.ReturnOnEquityTTM || "0",
          revenueGrowth: overview.QuarterlyRevenueGrowthYOY || "0",
        },
        earnings: {
          quarterlyEarnings: []
        }
      };
    } catch (error) {
      console.error(`Error fetching Alpha Vantage data for ${symbol}:`, error);
      return null;
    }
  }

  private combineAndProcessData(
    issuer: Issuer,
    yahooData: YahooFinanceData | null,
    alphaVantageData: AlphaVantageData | null
  ): InsertFeature | null {
    if (!yahooData && !alphaVantageData) {
      return null;
    }

    const features: InsertFeature = {
      issuerId: issuer.id,
      timestamp: new Date(),
      stockPrice: yahooData?.price?.toString() || "0",
      priceChange7d: yahooData?.changePercent?.toString() || "0",
      priceChange90d: "0", // Would need historical data for this
      volatility: "0", // Would calculate from historical data
      leverageRatio: alphaVantageData?.overview.debtToEquity || "0",
      debtToEquity: alphaVantageData?.overview.debtToEquity || "0",
      cashCoverage: "0", // Would need balance sheet data
      revenueGrowth: alphaVantageData?.overview.revenueGrowth || "0",
      additionalFeatures: {
        marketCap: yahooData?.marketCap || alphaVantageData?.overview.marketCap || "0",
        volume: yahooData?.volume || 0,
        pegRatio: alphaVantageData?.overview.pegRatio || "0",
        bookValue: alphaVantageData?.overview.bookValue || "0",
        returnOnEquity: alphaVantageData?.overview.returnOnEquity || "0",
        dataSource: {
          yahoo: !!yahooData,
          alphaVantage: !!alphaVantageData,
        }
      }
    };

    return features;
  }

  async ingestAllIssuers(): Promise<void> {
    try {
      const issuers = await storage.getIssuers();
      console.log(`Starting data ingestion for ${issuers.length} issuers`);

      for (const issuer of issuers) {
        try {
          await this.ingestDataForIssuer(issuer);
          // Add delay to respect API rate limits
          await new Promise(resolve => setTimeout(resolve, 1000));
        } catch (error) {
          console.error(`Failed to ingest data for ${issuer.symbol}:`, error);
        }
      }

      console.log("Completed data ingestion for all issuers");
    } catch (error) {
      console.error("Error in batch data ingestion:", error);
      throw error;
    }
  }
}

export const dataIngestionService = new DataIngestionService();