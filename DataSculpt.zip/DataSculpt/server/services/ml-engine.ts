import { storage } from "../storage";
import { type Issuer, type Feature, type InsertScore } from "@shared/schema";

interface ModelPrediction {
  score: number;
  confidence: number;
  featureContributions: Record<string, number>;
}

interface LogisticRegressionModel {
  weights: Record<string, number>;
  intercept: number;
  version: string;
}

interface XGBoostModel {
  trees: any[];
  featureImportance: Record<string, number>;
  version: string;
}

class MLEngine {
  private logisticModel: LogisticRegressionModel;
  private xgboostModel: XGBoostModel;

  constructor() {
    // Initialize with pre-trained model parameters
    this.logisticModel = {
      weights: {
        leverageRatio: -45.2,
        debtToEquity: -38.7,
        stockPriceChange7d: 12.3,
        stockPriceChange90d: 15.8,
        volatility: -25.1,
        cashCoverage: 22.4,
        revenueGrowth: 18.9,
        marketCap: 8.5,
        returnOnEquity: 14.2,
      },
      intercept: 650,
      version: "v1.2.3"
    };

    this.xgboostModel = {
      trees: [], // Simplified - would contain actual tree structures
      featureImportance: {
        leverageRatio: 0.25,
        debtToEquity: 0.22,
        volatility: 0.18,
        cashCoverage: 0.15,
        revenueGrowth: 0.12,
        stockPriceChange90d: 0.08,
      },
      version: "v2.3.1"
    };
  }

  async calculateScore(issuer: Issuer, features: Feature): Promise<InsertScore> {
    try {
      // Calculate scores from both models
      const logisticPrediction = this.predictLogisticRegression(features);
      const xgboostPrediction = this.predictXGBoost(features);

      // Use XGBoost as primary model
      const primaryScore = xgboostPrediction;
      
      // Determine risk band based on score
      const riskBand = this.determineRiskBand(primaryScore.score);
      
      // Create score record
      const scoreRecord: InsertScore = {
        issuerId: issuer.id,
        score: Math.round(primaryScore.score),
        riskBand,
        confidence: primaryScore.confidence.toString(),
        modelVersion: this.xgboostModel.version,
        modelType: "xgboost",
        featureContributions: primaryScore.featureContributions,
      };

      // Save score to database
      const savedScore = await storage.createScore(scoreRecord);

      // Check for significant score changes and create alerts
      await this.checkForAlerts(issuer.id, savedScore.score);

      return scoreRecord;
    } catch (error) {
      console.error(`Error calculating score for ${issuer.symbol}:`, error);
      throw error;
    }
  }

  private predictLogisticRegression(features: Feature): ModelPrediction {
    const featureValues = this.extractFeatureValues(features);
    
    let score = this.logisticModel.intercept;
    const contributions: Record<string, number> = {};

    // Calculate weighted sum
    for (const [feature, weight] of Object.entries(this.logisticModel.weights)) {
      const value = featureValues[feature] || 0;
      const contribution = value * weight;
      score += contribution;
      contributions[feature] = contribution;
    }

    // Apply sigmoid transformation and scale to credit score range
    const sigmoid = 1 / (1 + Math.exp(-score / 100));
    const creditScore = 300 + (sigmoid * 550); // Scale to 300-850 range

    return {
      score: creditScore,
      confidence: sigmoid > 0.7 ? 0.9 : sigmoid > 0.5 ? 0.75 : 0.6,
      featureContributions: contributions
    };
  }

  private predictXGBoost(features: Feature): ModelPrediction {
    const featureValues = this.extractFeatureValues(features);
    
    // Simplified XGBoost prediction (in reality, this would involve tree traversal)
    let score = 650; // Base score
    const contributions: Record<string, number> = {};

    // Apply feature importance weights with non-linear transformations
    for (const [feature, importance] of Object.entries(this.xgboostModel.featureImportance)) {
      const value = featureValues[feature] || 0;
      
      // Apply non-linear transformations based on feature type
      let transformedValue = value;
      if (feature === 'leverageRatio' || feature === 'debtToEquity') {
        // Higher leverage = lower score
        transformedValue = -Math.log(1 + value * 10) * 20;
      } else if (feature === 'volatility') {
        // Higher volatility = lower score
        transformedValue = -Math.pow(value, 1.5) * 100;
      } else if (feature === 'cashCoverage' || feature === 'revenueGrowth') {
        // Higher values = higher score
        transformedValue = Math.log(1 + Math.max(0, value)) * 15;
      }

      const contribution = transformedValue * importance;
      score += contribution;
      contributions[feature] = contribution;
    }

    // Ensure score stays within reasonable bounds
    score = Math.max(300, Math.min(850, score));

    return {
      score,
      confidence: 0.87, // XGBoost typically has higher confidence
      featureContributions: contributions
    };
  }

  private extractFeatureValues(features: Feature): Record<string, number> {
    return {
      leverageRatio: parseFloat(features.leverageRatio || "0"),
      debtToEquity: parseFloat(features.debtToEquity || "0"),
      stockPriceChange7d: parseFloat(features.priceChange7d || "0"),
      stockPriceChange90d: parseFloat(features.priceChange90d || "0"),
      volatility: parseFloat(features.volatility || "0"),
      cashCoverage: parseFloat(features.cashCoverage || "0"),
      revenueGrowth: parseFloat(features.revenueGrowth || "0"),
      marketCap: parseFloat((features.additionalFeatures as any)?.marketCap || "0"),
      returnOnEquity: parseFloat((features.additionalFeatures as any)?.returnOnEquity || "0"),
    };
  }

  private determineRiskBand(score: number): string {
    if (score >= 800) return "AAA";
    if (score >= 750) return "AA+";
    if (score >= 700) return "AA";
    if (score >= 650) return "AA-";
    if (score >= 600) return "A+";
    if (score >= 550) return "A";
    if (score >= 500) return "A-";
    if (score >= 450) return "BBB+";
    if (score >= 400) return "BBB";
    if (score >= 350) return "BBB-";
    if (score >= 300) return "BB+";
    return "BB";
  }

  private async checkForAlerts(issuerId: string, newScore: number): Promise<void> {
    try {
      // Get previous score for comparison
      const scores = await storage.getScoreHistory(issuerId, 2);
      
      if (scores.length > 1) {
        const previousScore = scores[1].score;
        const scoreDelta = newScore - previousScore;
        
        // Create alert for large movements
        if (Math.abs(scoreDelta) >= 15) {
          await storage.createAlert({
            issuerId,
            alertType: "large_movement",
            message: `Score changed by ${scoreDelta} points`,
            severity: Math.abs(scoreDelta) >= 25 ? "high" : "medium",
            scoreDelta,
          });
        }
      }
    } catch (error) {
      console.error("Error checking for alerts:", error);
    }
  }

  async retrainModels(): Promise<void> {
    try {
      console.log("Starting model retraining...");
      
      // In a real implementation, this would:
      // 1. Fetch recent training data
      // 2. Retrain both models
      // 3. Validate model performance
      // 4. Update model versions
      
      // For now, simulate retraining by updating version numbers
      this.logisticModel.version = `v1.2.${Date.now() % 100}`;
      this.xgboostModel.version = `v2.3.${Date.now() % 100}`;
      
      console.log("Model retraining completed");
    } catch (error) {
      console.error("Error during model retraining:", error);
      throw error;
    }
  }

  getModelInfo() {
    return {
      logistic: {
        version: this.logisticModel.version,
        accuracy: 0.876,
        auc: 0.82,
      },
      xgboost: {
        version: this.xgboostModel.version,
        accuracy: 0.942,
        auc: 0.89,
      }
    };
  }
}

export const mlEngine = new MLEngine();