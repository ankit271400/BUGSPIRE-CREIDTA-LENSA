import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertIssuerSchema, insertEventSchema, insertScoreSchema, insertAlertSchema } from "@shared/schema";
import { dataIngestionService } from "./services/data-ingestion";
import { mlEngine } from "./services/ml-engine";
import { nlpProcessor } from "./services/nlp-processor";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all issuers
  app.get("/api/issuers", async (req, res) => {
    try {
      const issuers = await storage.getIssuers();
      res.json(issuers);
    } catch (error) {
      console.error("Error fetching issuers:", error);
      res.status(500).json({ message: "Failed to fetch issuers" });
    }
  });

  // Get issuer by symbol
  app.get("/api/issuers/:symbol", async (req, res) => {
    try {
      const issuer = await storage.getIssuerBySymbol(req.params.symbol);
      if (!issuer) {
        return res.status(404).json({ message: "Issuer not found" });
      }
      res.json(issuer);
    } catch (error) {
      console.error("Error fetching issuer:", error);
      res.status(500).json({ message: "Failed to fetch issuer" });
    }
  });

  // Create new issuer
  app.post("/api/issuers", async (req, res) => {
    try {
      const validation = insertIssuerSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid issuer data", errors: validation.error.errors });
      }
      
      const issuer = await storage.createIssuer(validation.data);
      res.status(201).json(issuer);
    } catch (error) {
      console.error("Error creating issuer:", error);
      res.status(500).json({ message: "Failed to create issuer" });
    }
  });

  // Get latest score for issuer
  app.get("/api/issuers/:symbol/score", async (req, res) => {
    try {
      const issuer = await storage.getIssuerBySymbol(req.params.symbol);
      if (!issuer) {
        return res.status(404).json({ message: "Issuer not found" });
      }

      const score = await storage.getLatestScore(issuer.id);
      if (!score) {
        return res.status(404).json({ message: "No score found for issuer" });
      }

      res.json(score);
    } catch (error) {
      console.error("Error fetching score:", error);
      res.status(500).json({ message: "Failed to fetch score" });
    }
  });

  // Get score history for issuer
  app.get("/api/issuers/:symbol/scores", async (req, res) => {
    try {
      const issuer = await storage.getIssuerBySymbol(req.params.symbol);
      if (!issuer) {
        return res.status(404).json({ message: "Issuer not found" });
      }

      const limit = parseInt(req.query.limit as string) || 30;
      const scores = await storage.getScoreHistory(issuer.id, limit);
      res.json(scores);
    } catch (error) {
      console.error("Error fetching score history:", error);
      res.status(500).json({ message: "Failed to fetch score history" });
    }
  });

  // Get recent events for issuer
  app.get("/api/issuers/:symbol/events", async (req, res) => {
    try {
      const issuer = await storage.getIssuerBySymbol(req.params.symbol);
      if (!issuer) {
        return res.status(404).json({ message: "Issuer not found" });
      }

      const limit = parseInt(req.query.limit as string) || 10;
      const events = await storage.getRecentEvents(issuer.id, limit);
      res.json(events);
    } catch (error) {
      console.error("Error fetching events:", error);
      res.status(500).json({ message: "Failed to fetch events" });
    }
  });

  // Get event impacts for issuer
  app.get("/api/issuers/:symbol/impacts", async (req, res) => {
    try {
      const issuer = await storage.getIssuerBySymbol(req.params.symbol);
      if (!issuer) {
        return res.status(404).json({ message: "Issuer not found" });
      }

      const limit = parseInt(req.query.limit as string) || 10;
      const impacts = await storage.getEventImpacts(issuer.id, limit);
      res.json(impacts);
    } catch (error) {
      console.error("Error fetching event impacts:", error);
      res.status(500).json({ message: "Failed to fetch event impacts" });
    }
  });

  // Get latest features for issuer
  app.get("/api/issuers/:symbol/features", async (req, res) => {
    try {
      const issuer = await storage.getIssuerBySymbol(req.params.symbol);
      if (!issuer) {
        return res.status(404).json({ message: "Issuer not found" });
      }

      const features = await storage.getLatestFeatures(issuer.id);
      if (!features) {
        return res.status(404).json({ message: "No features found for issuer" });
      }

      res.json(features);
    } catch (error) {
      console.error("Error fetching features:", error);
      res.status(500).json({ message: "Failed to fetch features" });
    }
  });

  // Get active alerts
  app.get("/api/alerts", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const alerts = await storage.getActiveAlerts(limit);
      res.json(alerts);
    } catch (error) {
      console.error("Error fetching alerts:", error);
      res.status(500).json({ message: "Failed to fetch alerts" });
    }
  });

  // Mark alert as read
  app.patch("/api/alerts/:id/read", async (req, res) => {
    try {
      await storage.markAlertAsRead(req.params.id);
      res.json({ message: "Alert marked as read" });
    } catch (error) {
      console.error("Error marking alert as read:", error);
      res.status(500).json({ message: "Failed to mark alert as read" });
    }
  });

  // Trigger data ingestion for issuer
  app.post("/api/issuers/:symbol/ingest", async (req, res) => {
    try {
      const issuer = await storage.getIssuerBySymbol(req.params.symbol);
      if (!issuer) {
        return res.status(404).json({ message: "Issuer not found" });
      }

      await dataIngestionService.ingestDataForIssuer(issuer);
      res.json({ message: "Data ingestion triggered successfully" });
    } catch (error) {
      console.error("Error triggering data ingestion:", error);
      res.status(500).json({ message: "Failed to trigger data ingestion" });
    }
  });

  // Trigger score calculation for issuer
  app.post("/api/issuers/:symbol/score", async (req, res) => {
    try {
      const issuer = await storage.getIssuerBySymbol(req.params.symbol);
      if (!issuer) {
        return res.status(404).json({ message: "Issuer not found" });
      }

      const features = await storage.getLatestFeatures(issuer.id);
      if (!features) {
        return res.status(400).json({ message: "No features available for scoring" });
      }

      const score = await mlEngine.calculateScore(issuer, features);
      res.json(score);
    } catch (error) {
      console.error("Error calculating score:", error);
      res.status(500).json({ message: "Failed to calculate score" });
    }
  });

  // Process news for issuer
  app.post("/api/issuers/:symbol/process-news", async (req, res) => {
    try {
      const issuer = await storage.getIssuerBySymbol(req.params.symbol);
      if (!issuer) {
        return res.status(404).json({ message: "Issuer not found" });
      }

      const processedEvents = await nlpProcessor.processNewsForIssuer(issuer);
      res.json({ 
        message: "News processing completed", 
        eventsProcessed: processedEvents.length 
      });
    } catch (error) {
      console.error("Error processing news:", error);
      res.status(500).json({ message: "Failed to process news" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
