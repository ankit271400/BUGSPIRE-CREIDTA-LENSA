import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bell, ChartLine, Info, Brain, GitBranch } from "lucide-react";
import ScoreChart from "@/components/ScoreChart";
import FeatureContributions from "@/components/FeatureContributions";
import RecentEvents from "@/components/RecentEvents";
import AlertsTable from "@/components/AlertsTable";
import QuickStats from "@/components/QuickStats";

export default function Dashboard() {
  const [selectedIssuer, setSelectedIssuer] = useState("AAPL");
  const [currentTime, setCurrentTime] = useState(new Date());

  // Update time every 30 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(new Date());
    }, 30000);
    return () => clearInterval(interval);
  }, []);

  // Fetch issuers
  const { data: issuers = [] } = useQuery({
    queryKey: ["/api/issuers"],
  });

  // Fetch current score
  const { data: currentScore } = useQuery({
    queryKey: ["/api/issuers", selectedIssuer, "score"],
    enabled: !!selectedIssuer,
  });

  // Fetch score history
  const { data: scoreHistory = [] } = useQuery({
    queryKey: ["/api/issuers", selectedIssuer, "scores"],
    enabled: !!selectedIssuer,
  });

  // Fetch recent events
  const { data: recentEvents = [] } = useQuery({
    queryKey: ["/api/issuers", selectedIssuer, "events"],
    enabled: !!selectedIssuer,
  });

  // Fetch event impacts
  const { data: eventImpacts = [] } = useQuery({
    queryKey: ["/api/issuers", selectedIssuer, "impacts"],
    enabled: !!selectedIssuer,
  });

  // Fetch features
  const { data: features } = useQuery({
    queryKey: ["/api/issuers", selectedIssuer, "features"],
    enabled: !!selectedIssuer,
  });

  // Fetch alerts
  const { data: alerts = [] } = useQuery({
    queryKey: ["/api/alerts"],
  });

  const unreadAlerts = alerts.filter((alert: any) => !alert.isRead);

  const calculateScoreChange = () => {
    if (!Array.isArray(scoreHistory) || scoreHistory.length < 2) return 0;
    return scoreHistory[0].score - scoreHistory[1].score;
  };

  return (
    <div className="min-h-screen bg-dark-bg text-text-primary font-sans">
      {/* Header */}
      <header className="bg-surface-dark border-b border-border-subtle">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <ChartLine className="h-8 w-8 text-primary-blue" />
                <h1 className="text-xl font-semibold">Bugspire Credita Lensa</h1>
              </div>
              <div className="hidden md:flex items-center space-x-2 px-3 py-1 bg-success-green/10 rounded-full">
                <div className="w-2 h-2 bg-success-green rounded-full animate-pulse"></div>
                <span className="text-sm text-success-green">System Operational</span>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Button
                  variant="outline"
                  size="sm"
                  className="relative p-2 bg-surface-light border-border-subtle hover:bg-surface-dark"
                  data-testid="button-alerts"
                >
                  <Bell className="h-4 w-4 text-warning-orange" />
                  {unreadAlerts.length > 0 && (
                    <Badge 
                      variant="destructive" 
                      className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center text-xs"
                      data-testid="badge-alert-count"
                    >
                      {unreadAlerts.length}
                    </Badge>
                  )}
                </Button>
              </div>
              
              <div className="text-sm text-text-secondary" data-testid="text-last-updated">
                Last updated: {currentTime.toLocaleTimeString()}
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Score Overview */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-3 bg-surface-dark rounded-xl p-6 border border-border-subtle">
            <div className="flex justify-between items-start mb-6">
              <div>
                <h2 className="text-lg font-semibold mb-2">Credit Score Overview</h2>
                <div className="flex items-center space-x-4">
                  <Select value={selectedIssuer} onValueChange={setSelectedIssuer}>
                    <SelectTrigger 
                      className="w-48 bg-surface-light border-border-subtle text-text-primary"
                      data-testid="select-issuer"
                    >
                      <SelectValue placeholder="Select issuer" />
                    </SelectTrigger>
                    <SelectContent className="bg-surface-dark border-border-subtle">
                      {Array.isArray(issuers) ? issuers.map((issuer: any) => (
                        <SelectItem key={issuer.symbol} value={issuer.symbol} data-testid={`option-issuer-${issuer.symbol}`}>
                          {issuer.name} ({issuer.symbol})
                        </SelectItem>
                      )) : null}
                    </SelectContent>
                  </Select>
                  
                  <div className="flex items-center space-x-2 text-sm text-text-secondary">
                    <span>vs Agency Rating:</span>
                    <Badge variant="outline" className="bg-primary-blue/20 text-primary-blue border-primary-blue/30 font-mono">
                      AA-
                    </Badge>
                  </div>
                </div>
              </div>
              
              <div className="text-right">
                <div className="text-3xl font-bold font-mono" data-testid="text-current-score">
                  {currentScore?.score || 605}
                </div>
                <div className="flex items-center justify-end space-x-1 text-sm">
                  {calculateScoreChange() !== 0 && (
                    <>
                      <span className={`font-mono ${calculateScoreChange() < 0 ? 'text-error-red' : 'text-success-green'}`}>
                        {calculateScoreChange() > 0 ? '+' : ''}{calculateScoreChange()}
                      </span>
                      <span className="text-text-muted">7d</span>
                    </>
                  )}
                </div>
              </div>
            </div>
            
            <ScoreChart scores={Array.isArray(scoreHistory) ? scoreHistory : []} events={Array.isArray(recentEvents) ? recentEvents : []} />
          </div>
          
          <QuickStats 
            score={currentScore}
            features={features}
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <FeatureContributions 
            score={currentScore}
            features={features}
          />
          
          <RecentEvents 
            events={Array.isArray(recentEvents) ? recentEvents : []}
            impacts={Array.isArray(eventImpacts) ? eventImpacts : []}
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <AlertsTable alerts={Array.isArray(alerts) ? alerts : []} />
          </div>
          
          <div className="bg-surface-dark rounded-xl p-6 border border-border-subtle">
            <h3 className="text-lg font-semibold mb-4">Model Performance</h3>
            
            <div className="space-y-4">
              <div className="p-4 bg-surface-light rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium">XGBoost v2.3.1</span>
                  <Badge className="bg-success-green text-white">Primary</Badge>
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <div className="text-text-secondary">Accuracy</div>
                    <div className="font-mono font-medium" data-testid="text-xgboost-accuracy">94.2%</div>
                  </div>
                  <div>
                    <div className="text-text-secondary">AUC</div>
                    <div className="font-mono font-medium" data-testid="text-xgboost-auc">0.89</div>
                  </div>
                </div>
              </div>
              
              <div className="p-4 bg-surface-light rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium">Logistic Regression</span>
                  <Badge variant="secondary" className="bg-text-muted text-white">Baseline</Badge>
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <div className="text-text-secondary">Accuracy</div>
                    <div className="font-mono font-medium" data-testid="text-logreg-accuracy">87.6%</div>
                  </div>
                  <div>
                    <div className="text-text-secondary">AUC</div>
                    <div className="font-mono font-medium" data-testid="text-logreg-auc">0.82</div>
                  </div>
                </div>
              </div>
              
              <div className="text-sm text-text-secondary space-y-1">
                <div className="flex justify-between">
                  <span>Last Training:</span>
                  <span data-testid="text-last-training">12h ago</span>
                </div>
                <div className="flex justify-between">
                  <span>Next Training:</span>
                  <span data-testid="text-next-training">12h</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
