import { ChartLine, TrendingDown, Shield, DollarSign, Info } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface FeatureContributionsProps {
  score: any;
  features: any;
}

export default function FeatureContributions({ score, features }: FeatureContributionsProps) {
  const getFeatureContributions = () => {
    if (!score?.featureContributions) {
      return [
        {
          name: "Leverage Ratio",
          value: parseFloat(features?.leverageRatio || "0"),
          impact: -23,
          icon: ChartLine,
          iconColor: "text-error-red",
          bgColor: "bg-error-red/20",
          description: `Debt/Equity: ${parseFloat(features?.debtToEquity || "0").toFixed(2)}`
        },
        {
          name: "Stock Momentum",
          value: parseFloat(features?.priceChange90d || "0"),
          impact: -18,
          icon: TrendingDown,
          iconColor: "text-error-red",
          bgColor: "bg-error-red/20",
          description: `90D Return: ${parseFloat(features?.priceChange90d || "0").toFixed(1)}%`
        },
        {
          name: "Cash Coverage",
          value: parseFloat(features?.cashCoverage || "1.4"),
          impact: 12,
          icon: Shield,
          iconColor: "text-success-green",
          bgColor: "bg-success-green/20",
          description: `Cash/Debt: ${parseFloat(features?.cashCoverage || "1.4").toFixed(1)}x`
        },
        {
          name: "Revenue Growth",
          value: parseFloat(features?.revenueGrowth || "0"),
          impact: 8,
          icon: DollarSign,
          iconColor: "text-success-green",
          bgColor: "bg-success-green/20",
          description: `YoY: +${parseFloat(features?.revenueGrowth || "15.2").toFixed(1)}%`
        }
      ];
    }

    // Convert feature contributions to display format
    return Object.entries(score.featureContributions).map(([feature, impact]) => {
      const numericImpact = typeof impact === 'number' ? impact : 0;
      return {
        name: feature.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase()),
        value: parseFloat(features?.[feature] || "0"),
        impact: Math.round(numericImpact),
        icon: numericImpact < 0 ? ChartLine : Shield,
        iconColor: numericImpact < 0 ? "text-error-red" : "text-success-green",
        bgColor: numericImpact < 0 ? "bg-error-red/20" : "bg-success-green/20",
        description: `Current: ${parseFloat(features?.[feature] || "0").toFixed(2)}`
      };
    });
  };

  const contributions = getFeatureContributions();

  const generateAISummary = () => {
    const negativeImpacts = contributions.filter(c => c.impact < 0);
    const positiveImpacts = contributions.filter(c => c.impact > 0);
    
    let summary = "Score ";
    
    if (negativeImpacts.length > 0) {
      summary += "declined primarily due to ";
      summary += negativeImpacts.slice(0, 2).map(c => c.name.toLowerCase()).join(" and ");
    }
    
    if (positiveImpacts.length > 0) {
      if (negativeImpacts.length > 0) {
        summary += ", partially offset by ";
      } else {
        summary += "improved due to ";
      }
      summary += positiveImpacts.slice(0, 2).map(c => c.name.toLowerCase()).join(" and ");
    }
    
    summary += ".";
    return summary;
  };

  return (
    <div className="bg-surface-dark rounded-xl p-6 border border-border-subtle">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold">Score Drivers</h3>
        <div className="flex items-center space-x-2 text-sm text-text-secondary">
          <span>Impact Analysis</span>
          <Info className="h-4 w-4" />
        </div>
      </div>
      
      <div className="space-y-4">
        {contributions.map((contribution, index) => {
          const IconComponent = contribution.icon;
          return (
            <div 
              key={index} 
              className="flex items-center justify-between p-3 bg-surface-light rounded-lg"
              data-testid={`feature-contribution-${index}`}
            >
              <div className="flex items-center space-x-3">
                <div className={`w-8 h-8 ${contribution.bgColor} rounded-lg flex items-center justify-center`}>
                  <IconComponent className={`${contribution.iconColor} text-sm h-4 w-4`} />
                </div>
                <div>
                  <div className="font-medium" data-testid={`feature-name-${index}`}>
                    {contribution.name}
                  </div>
                  <div className="text-sm text-text-secondary" data-testid={`feature-description-${index}`}>
                    {contribution.description}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div 
                  className={`font-mono ${contribution.impact < 0 ? 'text-error-red' : 'text-success-green'}`}
                  data-testid={`feature-impact-${index}`}
                >
                  {contribution.impact > 0 ? '+' : ''}{contribution.impact}pts
                </div>
                <div className="text-sm text-text-muted">
                  {contribution.impact < 0 ? '↑ Risk' : '↓ Risk'}
                </div>
              </div>
            </div>
          );
        })}
      </div>
      
      <div className="mt-4 p-3 bg-primary-blue/10 rounded-lg border border-primary-blue/20">
        <div className="text-sm">
          <strong className="text-primary-blue">AI Summary:</strong> 
          <span className="text-text-secondary ml-1" data-testid="text-ai-summary">
            {generateAISummary()}
          </span>
        </div>
      </div>
    </div>
  );
}
