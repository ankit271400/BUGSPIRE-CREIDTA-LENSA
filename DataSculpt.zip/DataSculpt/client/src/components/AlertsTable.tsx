import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

interface AlertsTableProps {
  alerts: any[];
}

export default function AlertsTable({ alerts }: AlertsTableProps) {
  const queryClient = useQueryClient();

  const markAsReadMutation = useMutation({
    mutationFn: (alertId: string) => apiRequest('PATCH', `/api/alerts/${alertId}/read`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/alerts'] });
    },
  });

  const getStatusColor = (isRead: boolean) => {
    return isRead ? 'bg-text-muted' : 'bg-warning-orange';
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'bg-error-red/20 text-error-red';
      case 'medium': return 'bg-warning-orange/20 text-warning-orange';
      case 'low': return 'bg-primary-blue/20 text-primary-blue';
      default: return 'bg-text-muted/20 text-text-muted';
    }
  };

  const getTimeAgo = (timestamp: string) => {
    const now = new Date();
    const alertTime = new Date(timestamp);
    const diffMs = now.getTime() - alertTime.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffHours / 24);
    
    if (diffDays > 0) {
      return `${diffDays}d ago`;
    } else if (diffHours > 0) {
      return `${diffHours}h ago`;
    } else {
      return 'Just now';
    }
  };

  const displayAlerts = alerts.slice(0, 5);

  return (
    <div className="bg-surface-dark rounded-xl p-6 border border-border-subtle">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold">Active Alerts</h3>
        <div className="flex items-center space-x-2">
          <Button 
            variant="outline" 
            size="sm" 
            className="px-3 py-1 bg-surface-light border-border-subtle hover:bg-surface-dark text-sm"
            data-testid="button-filter-alerts"
          >
            Filter
          </Button>
          <Button 
            variant="default" 
            size="sm" 
            className="px-3 py-1 bg-primary-blue text-white text-sm"
            data-testid="button-mark-all-read"
          >
            Mark All Read
          </Button>
        </div>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-border-subtle">
              <th className="text-left py-3 px-2 font-medium text-sm text-text-secondary">Issuer</th>
              <th className="text-left py-3 px-2 font-medium text-sm text-text-secondary">Alert Type</th>
              <th className="text-left py-3 px-2 font-medium text-sm text-text-secondary">Score Change</th>
              <th className="text-left py-3 px-2 font-medium text-sm text-text-secondary">Time</th>
              <th className="text-left py-3 px-2 font-medium text-sm text-text-secondary">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border-subtle">
            {displayAlerts.length === 0 ? (
              <tr>
                <td colSpan={5} className="py-8 text-center text-text-muted">
                  No alerts to display
                </td>
              </tr>
            ) : (
              displayAlerts.map((alert, index) => (
                <tr 
                  key={alert.id} 
                  className="hover:bg-surface-light/50 transition-colors"
                  data-testid={`alert-row-${index}`}
                >
                  <td className="py-3 px-2">
                    <div className="font-medium" data-testid={`alert-issuer-${index}`}>
                      {alert.issuer?.name || 'Unknown Issuer'}
                    </div>
                    <div className="text-xs text-text-secondary">
                      {alert.issuer?.symbol || 'N/A'}
                    </div>
                  </td>
                  <td className="py-3 px-2">
                    <Badge 
                      className={`text-xs ${getSeverityColor(alert.severity)}`}
                      data-testid={`alert-type-${index}`}
                    >
                      {alert.alertType.replace(/_/g, ' ').replace(/\b\w/g, (l: string) => l.toUpperCase())}
                    </Badge>
                  </td>
                  <td className="py-3 px-2">
                    <span 
                      className={`font-mono ${alert.scoreDelta < 0 ? 'text-error-red' : alert.scoreDelta > 0 ? 'text-success-green' : 'text-text-secondary'}`}
                      data-testid={`alert-score-delta-${index}`}
                    >
                      {alert.scoreDelta ? `${alert.scoreDelta > 0 ? '+' : ''}${alert.scoreDelta}pts` : '-'}
                    </span>
                  </td>
                  <td className="py-3 px-2 text-sm text-text-secondary" data-testid={`alert-time-${index}`}>
                    {getTimeAgo(alert.createdAt)}
                  </td>
                  <td className="py-3 px-2">
                    <button
                      onClick={() => !alert.isRead && markAsReadMutation.mutate(alert.id)}
                      className="cursor-pointer"
                      data-testid={`alert-status-${index}`}
                    >
                      <span className={`w-2 h-2 ${getStatusColor(alert.isRead)} rounded-full inline-block`}></span>
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
