import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface RecentEventsProps {
  events: any[];
  impacts: any[];
}

export default function RecentEvents({ events, impacts }: RecentEventsProps) {
  const getEventImpact = (eventId: string) => {
    return impacts.find(impact => impact.eventId === eventId);
  };

  const getTimeAgo = (timestamp: string) => {
    const now = new Date();
    const eventTime = new Date(timestamp);
    const diffMs = now.getTime() - eventTime.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffHours / 24);
    
    if (diffDays > 0) {
      return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
    } else if (diffHours > 0) {
      return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    } else {
      return 'Just now';
    }
  };

  const getBorderColor = (sentiment: string) => {
    switch (sentiment) {
      case 'negative': return 'border-error-red';
      case 'positive': return 'border-success-green';
      default: return 'border-warning-orange';
    }
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'negative': return 'bg-error-red/20 text-error-red';
      case 'positive': return 'bg-success-green/20 text-success-green';
      default: return 'bg-warning-orange/20 text-warning-orange';
    }
  };

  const getImpactColor = (scoreDelta: number) => {
    if (scoreDelta < -10) return 'text-error-red';
    if (scoreDelta < -5) return 'text-warning-orange';
    if (scoreDelta > 5) return 'text-success-green';
    return 'text-text-secondary';
  };

  const getImpactMagnitude = (scoreDelta: number) => {
    const abs = Math.abs(scoreDelta);
    if (abs >= 15) return 'High Impact';
    if (abs >= 8) return 'Medium';
    return 'Low';
  };

  const displayEvents = events.slice(0, 3);

  return (
    <div className="bg-surface-dark rounded-xl p-6 border border-border-subtle">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold">Recent Events & Impact</h3>
        <Button 
          variant="link" 
          className="text-primary-blue hover:text-primary-blue/80 text-sm p-0"
          data-testid="button-view-all-events"
        >
          View All <ArrowRight className="ml-1 h-4 w-4" />
        </Button>
      </div>
      
      <div className="space-y-4">
        {displayEvents.length === 0 ? (
          <div className="text-center py-8 text-text-muted">
            <p>No recent events available</p>
          </div>
        ) : (
          displayEvents.map((event, index) => {
            const impact = getEventImpact(event.id);
            const scoreDelta = impact?.scoreDelta || 0;
            
            return (
              <div 
                key={index} 
                className={`border-l-4 ${getBorderColor(event.sentiment)} pl-4 pb-4`}
                data-testid={`event-${index}`}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <div className="font-medium text-sm" data-testid={`event-title-${index}`}>
                      {event.title}
                    </div>
                    <div className="text-xs text-text-secondary" data-testid={`event-meta-${index}`}>
                      {getTimeAgo(event.publishedAt)} • {event.source}
                    </div>
                  </div>
                  <div className="text-right ml-4">
                    <div className={`font-mono text-sm ${getImpactColor(scoreDelta)}`} data-testid={`event-impact-${index}`}>
                      {scoreDelta !== 0 ? `${scoreDelta > 0 ? '+' : ''}${scoreDelta}pts` : '-'}
                    </div>
                    {scoreDelta !== 0 && (
                      <div className="text-xs text-text-muted">
                        {getImpactMagnitude(scoreDelta)}
                      </div>
                    )}
                  </div>
                </div>
                
                <p className="text-sm text-text-secondary leading-relaxed mb-2" data-testid={`event-content-${index}`}>
                  {event.content ? 
                    (event.content.length > 120 ? event.content.substring(0, 120) + '...' : event.content)
                    : 'No content available for this event.'
                  }
                </p>
                
                <div className="flex items-center space-x-2">
                  <Badge 
                    className={`text-xs ${getSentimentColor(event.sentiment)}`}
                    data-testid={`event-sentiment-${index}`}
                  >
                    {event.sentiment ? 
                      event.sentiment.charAt(0).toUpperCase() + event.sentiment.slice(1) 
                      : 'Neutral'
                    }
                  </Badge>
                  <Badge 
                    variant="outline" 
                    className="bg-surface-light text-text-muted border-border-subtle text-xs"
                    data-testid={`event-type-${index}`}
                  >
                    {event.eventType ? 
                      event.eventType.replace(/_/g, ' ').replace(/\b\w/g, (l: string) => l.toUpperCase())
                      : 'General'
                    }
                  </Badge>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
