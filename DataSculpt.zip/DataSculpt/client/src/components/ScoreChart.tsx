import { useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';

interface ScoreChartProps {
  scores: any[];
  events: any[];
}

export default function ScoreChart({ scores, events }: ScoreChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef = useRef<any>(null);

  useEffect(() => {
    if (!canvasRef.current || typeof window === 'undefined') return;

    // Dynamically import Chart.js to avoid SSR issues
    import('chart.js/auto').then((ChartJS) => {
      const Chart = ChartJS.default;
      
      if (chartRef.current) {
        chartRef.current.destroy();
      }

      const ctx = canvasRef.current!.getContext('2d')!;
      
      // Process score data
      const chartData = scores.slice().reverse().map((score, index) => ({
        x: index,
        y: score.score,
        timestamp: new Date(score.timestamp).toLocaleDateString()
      }));

      // Create event markers
      const eventAnnotations = events.slice(0, 5).map((event, index) => ({
        x: Math.floor(chartData.length * (index + 1) / 6), // Distribute events across timeline
        y: chartData[Math.floor(chartData.length * (index + 1) / 6)]?.y || 600,
        title: event.title,
        sentiment: event.sentiment
      }));

      chartRef.current = new Chart(ctx, {
        type: 'line',
        data: {
          datasets: [
            {
              label: 'Credit Score',
              data: chartData,
              borderColor: 'hsl(221, 82%, 53%)',
              backgroundColor: 'hsla(221, 82%, 53%, 0.1)',
              borderWidth: 2,
              fill: true,
              tension: 0.4,
              pointRadius: 4,
              pointHoverRadius: 6,
              pointBackgroundColor: 'hsl(221, 82%, 53%)',
              pointBorderColor: 'hsl(0, 0%, 95.7%)',
              pointBorderWidth: 2,
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              display: false
            },
            tooltip: {
              backgroundColor: 'hsl(0, 0%, 14.9%)',
              titleColor: 'hsl(0, 0%, 95.7%)',
              bodyColor: 'hsl(0, 0%, 77.6%)',
              borderColor: 'hsl(0, 0%, 22.4%)',
              borderWidth: 1,
              callbacks: {
                title: function(tooltipItems) {
                  const dataPoint = chartData[tooltipItems[0].dataIndex];
                  return dataPoint.timestamp;
                },
                label: function(context) {
                  return `Score: ${context.parsed.y}`;
                }
              }
            }
          },
          scales: {
            x: {
              type: 'linear',
              grid: {
                color: 'hsl(0, 0%, 22.4%)'
              },
              ticks: {
                color: 'hsl(0, 0%, 43.5%)',
                callback: function(value, index) {
                  const dataPoint = chartData[index];
                  return dataPoint ? dataPoint.timestamp : '';
                },
                maxTicksLimit: 6
              }
            },
            y: {
              grid: {
                color: 'hsl(0, 0%, 22.4%)'
              },
              ticks: {
                color: 'hsl(0, 0%, 43.5%)'
              },
              min: Math.min(...chartData.map(d => d.y)) - 20,
              max: Math.max(...chartData.map(d => d.y)) + 20
            }
          },
          interaction: {
            intersect: false,
            mode: 'index'
          }
        }
      });
    });

    return () => {
      if (chartRef.current) {
        chartRef.current.destroy();
      }
    };
  }, [scores, events]);

  return (
    <div className="space-y-4">
      <div className="h-80 relative">
        <canvas ref={canvasRef} className="w-full h-full" data-testid="canvas-score-chart" />
      </div>
      
      <div className="flex justify-between items-center text-sm text-text-secondary">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-primary-blue rounded-full"></div>
            <span>Credit Score</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-warning-orange rounded-full"></div>
            <span>Events</span>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <Button 
            variant="outline" 
            size="sm" 
            className="px-3 py-1 bg-surface-light border-border-subtle hover:bg-surface-dark text-xs"
            data-testid="button-timeframe-7d"
          >
            7D
          </Button>
          <Button 
            variant="default" 
            size="sm" 
            className="px-3 py-1 bg-primary-blue text-white text-xs"
            data-testid="button-timeframe-30d"
          >
            30D
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            className="px-3 py-1 bg-surface-light border-border-subtle hover:bg-surface-dark text-xs"
            data-testid="button-timeframe-90d"
          >
            90D
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            className="px-3 py-1 bg-surface-light border-border-subtle hover:bg-surface-dark text-xs"
            data-testid="button-timeframe-1y"
          >
            1Y
          </Button>
        </div>
      </div>
    </div>
  );
}
