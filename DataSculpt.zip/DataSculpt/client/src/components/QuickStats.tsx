import { Info, ChartArea, Brain, GitBranch } from 'lucide-react';

interface QuickStatsProps {
  score: any;
  features: any;
}

export default function QuickStats({ score, features }: QuickStatsProps) {
  const getRiskGrade = (scoreValue: number) => {
    if (scoreValue >= 700) return { grade: 'AA+', category: 'Investment Grade', color: 'text-success-green' };
    if (scoreValue >= 650) return { grade: 'AA-', category: 'Investment Grade', color: 'text-success-green' };
    if (scoreValue >= 600) return { grade: 'A+', category: 'Investment Grade', color: 'text-success-green' };
    if (scoreValue >= 550) return { grade: 'BBB+', category: 'Investment Grade', color: 'text-success-green' };
    if (scoreValue >= 500) return { grade: 'BBB', category: 'Investment Grade', color: 'text-warning-orange' };
    if (scoreValue >= 450) return { grade: 'BBB-', category: 'High Yield', color: 'text-warning-orange' };
    return { grade: 'BB+', category: 'High Yield', color: 'text-error-red' };
  };

  const getVolatilityMetrics = () => {
    const volatility = parseFloat(features?.volatility || "2.4");
    const avgVolatility = 2.1; // Industry average
    const difference = volatility - avgVolatility;
    
    return {
      value: volatility.toFixed(1),
      comparison: difference > 0 ? `↑ ${difference.toFixed(1)}% vs avg` : `↓ ${Math.abs(difference).toFixed(1)}% vs avg`,
      color: difference > 0 ? 'text-error-red' : 'text-success-green'
    };
  };

  const getConfidenceLevel = (confidence: number) => {
    if (confidence >= 0.85) return { level: 'High', color: 'text-success-green' };
    if (confidence >= 0.7) return { level: 'Medium', color: 'text-warning-orange' };
    return { level: 'Low', color: 'text-error-red' };
  };

  const currentScore = score?.score || 605;
  const riskInfo = getRiskGrade(currentScore);
  const volatilityInfo = getVolatilityMetrics();
  const confidenceValue = score?.confidence || 0.87;
  const confidenceInfo = getConfidenceLevel(confidenceValue);

  return (
    <div className="space-y-4">
      <div className="bg-surface-dark rounded-xl p-4 border border-border-subtle">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-text-secondary">Risk Band</span>
          <Info className="h-4 w-4 text-text-muted" />
        </div>
        <div className="text-xl font-bold font-mono" data-testid="text-risk-band">
          {riskInfo.grade}
        </div>
        <div className={`text-sm ${riskInfo.color}`} data-testid="text-risk-category">
          {riskInfo.category}
        </div>
      </div>
      
      <div className="bg-surface-dark rounded-xl p-4 border border-border-subtle">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-text-secondary">Volatility</span>
          <ChartArea className="h-4 w-4 text-text-muted" />
        </div>
        <div className="text-xl font-bold font-mono" data-testid="text-volatility">
          {volatilityInfo.value}%
        </div>
        <div className={`text-sm ${volatilityInfo.color}`} data-testid="text-volatility-comparison">
          {volatilityInfo.comparison}
        </div>
      </div>
      
      <div className="bg-surface-dark rounded-xl p-4 border border-border-subtle">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-text-secondary">Confidence</span>
          <Brain className="h-4 w-4 text-text-muted" />
        </div>
        <div className="text-xl font-bold font-mono" data-testid="text-confidence">
          {Math.round(confidenceValue * 100)}%
        </div>
        <div className={`text-sm ${confidenceInfo.color}`} data-testid="text-confidence-level">
          {confidenceInfo.level}
        </div>
      </div>
      
      <div className="bg-surface-dark rounded-xl p-4 border border-border-subtle">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-text-secondary">Model Version</span>
          <GitBranch className="h-4 w-4 text-text-muted" />
        </div>
        <div className="text-xl font-bold font-mono" data-testid="text-model-version">
          {score?.modelVersion || 'v2.3.1'}
        </div>
        <div className="text-sm text-text-secondary" data-testid="text-model-type">
          {score?.modelType === 'xgboost' ? 'XGBoost' : 'Logistic Regression'}
        </div>
      </div>
    </div>
  );
}
