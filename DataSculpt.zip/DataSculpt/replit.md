# Overview

This is Bugspire Credita Lensa, a real-time credit risk monitoring system that provides automated credit scoring and risk assessment for financial issuers. The application combines structured financial data with unstructured news/events to generate dynamic credit scores using machine learning models. It features a modern web interface for monitoring issuer risk bands, viewing score histories, analyzing feature contributions, and managing risk alerts.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Library**: Radix UI components with shadcn/ui styling system
- **Styling**: Tailwind CSS with custom design tokens and dark mode support
- **State Management**: TanStack React Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Charts**: Chart.js for data visualization of credit score trends

## Backend Architecture
- **Runtime**: Node.js with Express.js REST API
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM for type-safe database operations
- **API Design**: RESTful endpoints with proper error handling and request logging
- **Build System**: esbuild for production bundling

## Database Schema
- **Issuers**: Companies/sovereigns being tracked (symbol, name, sector, country)
- **Features**: Time-series financial metrics (price data, ratios, growth metrics)
- **Scores**: ML model outputs with confidence levels and feature contributions
- **Events**: Unstructured data from news sources with sentiment analysis
- **Event Impacts**: Links between events and their impact on credit scores
- **Alerts**: Risk notifications with severity levels and read status

## Machine Learning Engine
- **Dual Model Approach**: Logistic Regression (interpretable) and XGBoost (accuracy)
- **Feature Engineering**: Combines structured financial data with NLP-processed events
- **Explainability**: Feature contribution tracking for model transparency
- **Risk Banding**: Credit scores mapped to traditional rating bands (AA+, BBB, etc.)

## Data Processing Pipeline
- **Structured Data Sources**: Yahoo Finance, Alpha Vantage for financial metrics
- **Unstructured Sources**: News APIs for real-time event monitoring
- **NLP Processing**: Sentiment analysis and event classification
- **Feature Decay**: Time-weighted importance for recent vs. historical events
- **Automated Ingestion**: Scheduled data collection with fallback handling

## External Dependencies

- **Database**: PostgreSQL with Neon serverless hosting
- **Financial APIs**: Yahoo Finance API, Alpha Vantage API for market data
- **News Sources**: News API for real-time event monitoring
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **Styling**: Tailwind CSS with PostCSS processing
- **Development**: Replit-specific tooling for development environment