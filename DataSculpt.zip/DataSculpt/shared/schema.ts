import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, timestamp, jsonb, uuid, boolean } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Issuer table - companies/sovereigns we track
export const issuers = pgTable("issuers", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  symbol: text("symbol").notNull().unique(),
  sector: text("sector"),
  country: text("country"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Features table - snapshot of financial & macro features at each time
export const features = pgTable("features", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  issuerId: uuid("issuer_id").notNull().references(() => issuers.id),
  timestamp: timestamp("timestamp").notNull(),
  stockPrice: decimal("stock_price", { precision: 10, scale: 2 }),
  priceChange7d: decimal("price_change_7d", { precision: 5, scale: 2 }),
  priceChange90d: decimal("price_change_90d", { precision: 5, scale: 2 }),
  volatility: decimal("volatility", { precision: 5, scale: 4 }),
  leverageRatio: decimal("leverage_ratio", { precision: 5, scale: 3 }),
  debtToEquity: decimal("debt_to_equity", { precision: 5, scale: 3 }),
  cashCoverage: decimal("cash_coverage", { precision: 5, scale: 2 }),
  revenueGrowth: decimal("revenue_growth", { precision: 5, scale: 2 }),
  additionalFeatures: jsonb("additional_features"),
});

// Scores table - model outputs (credit score, band, timestamp)
export const scores = pgTable("scores", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  issuerId: uuid("issuer_id").notNull().references(() => issuers.id),
  score: integer("score").notNull(),
  riskBand: text("risk_band").notNull(),
  confidence: decimal("confidence", { precision: 3, scale: 2 }),
  modelVersion: text("model_version").notNull(),
  modelType: text("model_type").notNull(), // 'logistic_regression' or 'xgboost'
  featureContributions: jsonb("feature_contributions"),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Events table - unstructured data (news headlines, press releases, transcripts)
export const events = pgTable("events", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  issuerId: uuid("issuer_id").notNull().references(() => issuers.id),
  title: text("title").notNull(),
  content: text("content"),
  source: text("source").notNull(),
  eventType: text("event_type"), // 'debt_restructuring', 'litigation', 'downgrade', 'guidance_cut', etc.
  sentiment: text("sentiment"), // 'positive', 'negative', 'neutral'
  confidence: decimal("confidence", { precision: 3, scale: 2 }),
  publishedAt: timestamp("published_at").notNull(),
  processedAt: timestamp("processed_at").defaultNow(),
});

// Event Impact table - links events with their score change and top drivers
export const eventImpacts = pgTable("event_impacts", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  eventId: uuid("event_id").notNull().references(() => events.id),
  issuerId: uuid("issuer_id").notNull().references(() => issuers.id),
  scorePre: integer("score_pre").notNull(),
  scorePost: integer("score_post").notNull(),
  scoreDelta: integer("score_delta").notNull(),
  impactMagnitude: text("impact_magnitude"), // 'low', 'medium', 'high'
  topDrivers: jsonb("top_drivers"),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Alerts table - system alerts for score movements
export const alerts = pgTable("alerts", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  issuerId: uuid("issuer_id").notNull().references(() => issuers.id),
  alertType: text("alert_type").notNull(), // 'large_movement', 'model_drift', 'data_quality'
  message: text("message").notNull(),
  severity: text("severity").notNull(), // 'low', 'medium', 'high'
  scoreDelta: integer("score_delta"),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const issuersRelations = relations(issuers, ({ many }) => ({
  features: many(features),
  scores: many(scores),
  events: many(events),
  eventImpacts: many(eventImpacts),
  alerts: many(alerts),
}));

export const featuresRelations = relations(features, ({ one }) => ({
  issuer: one(issuers, {
    fields: [features.issuerId],
    references: [issuers.id],
  }),
}));

export const scoresRelations = relations(scores, ({ one }) => ({
  issuer: one(issuers, {
    fields: [scores.issuerId],
    references: [issuers.id],
  }),
}));

export const eventsRelations = relations(events, ({ one, many }) => ({
  issuer: one(issuers, {
    fields: [events.issuerId],
    references: [issuers.id],
  }),
  impacts: many(eventImpacts),
}));

export const eventImpactsRelations = relations(eventImpacts, ({ one }) => ({
  event: one(events, {
    fields: [eventImpacts.eventId],
    references: [events.id],
  }),
  issuer: one(issuers, {
    fields: [eventImpacts.issuerId],
    references: [issuers.id],
  }),
}));

export const alertsRelations = relations(alerts, ({ one }) => ({
  issuer: one(issuers, {
    fields: [alerts.issuerId],
    references: [issuers.id],
  }),
}));

// Insert schemas
export const insertIssuerSchema = createInsertSchema(issuers).omit({
  id: true,
  createdAt: true,
});

export const insertFeatureSchema = createInsertSchema(features).omit({
  id: true,
});

export const insertScoreSchema = createInsertSchema(scores).omit({
  id: true,
  timestamp: true,
});

export const insertEventSchema = createInsertSchema(events).omit({
  id: true,
  processedAt: true,
});

export const insertEventImpactSchema = createInsertSchema(eventImpacts).omit({
  id: true,
  timestamp: true,
});

export const insertAlertSchema = createInsertSchema(alerts).omit({
  id: true,
  createdAt: true,
});

// Types
export type Issuer = typeof issuers.$inferSelect;
export type InsertIssuer = z.infer<typeof insertIssuerSchema>;

export type Feature = typeof features.$inferSelect;
export type InsertFeature = z.infer<typeof insertFeatureSchema>;

export type Score = typeof scores.$inferSelect;
export type InsertScore = z.infer<typeof insertScoreSchema>;

export type Event = typeof events.$inferSelect;
export type InsertEvent = z.infer<typeof insertEventSchema>;

export type EventImpact = typeof eventImpacts.$inferSelect;
export type InsertEventImpact = z.infer<typeof insertEventImpactSchema>;

export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = z.infer<typeof insertAlertSchema>;

// Legacy user schema for compatibility
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
